package models;

public enum EventType {
    PRIORITY, LOGGING, ERROR
}
