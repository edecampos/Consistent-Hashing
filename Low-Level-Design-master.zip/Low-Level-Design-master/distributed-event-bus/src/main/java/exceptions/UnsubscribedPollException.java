package exceptions;

public class UnsubscribedPollException extends RuntimeException {
}
