package models;

public enum EvictionAlgorithm {
    LRU, LFU
}
