package models;

public class Timer {
    public long getCurrentTime() {
        return System.nanoTime();
    }
}
