package models;

public enum FetchAlgorithm {
    WRITE_THROUGH, WRITE_BACK
}
