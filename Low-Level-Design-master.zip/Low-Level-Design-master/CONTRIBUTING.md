## Guidelines:

_Please do not post personal videos or podcast resources, unless relevant to system design._

Please give a short description of the link(s) before raising a pull request to add them.

Try to look for good video and blog sources 💪🙂
